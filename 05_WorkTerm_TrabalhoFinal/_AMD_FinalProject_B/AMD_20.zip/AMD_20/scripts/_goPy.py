import os
os.system( "_go00" )
