No script 02_script_IMPORT_POPULATE_SCHEMA, é necessário mudar a diretoria do ficheiro .csv.

O código remove_useless_products.py serve para remover as linhas cujo os produtos são inúteis ('home', 'open', /customer/...') e gera um novo dataset acabado em [...]_filtered.csv
