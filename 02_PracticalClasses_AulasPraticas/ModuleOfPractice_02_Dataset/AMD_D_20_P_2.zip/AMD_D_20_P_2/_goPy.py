import os
os.system( "_go30" )